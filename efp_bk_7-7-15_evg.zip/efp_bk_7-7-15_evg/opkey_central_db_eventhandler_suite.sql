CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eventhandler_suite`
--

DROP TABLE IF EXISTS `eventhandler_suite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventhandler_suite` (
  `Suite_EHandler_ID` varchar(63) NOT NULL,
  `suite_id` varchar(63) NOT NULL,
  `ehandler_id` varchar(63) NOT NULL,
  `Position` int(10) unsigned NOT NULL,
  PRIMARY KEY (`Suite_EHandler_ID`),
  UNIQUE KEY `UNIQUE` (`suite_id`,`ehandler_id`),
  KEY `FK_eventhandler_suite__meta_eventhandler` (`ehandler_id`),
  CONSTRAINT `FK_eventhandler_suite_MetaEventHandler` FOREIGN KEY (`ehandler_id`) REFERENCES `meta_eventhandler` (`ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_eventhandler_suite_Meta_Suite` FOREIGN KEY (`suite_id`) REFERENCES `meta_suite` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventhandler_suite`
--

LOCK TABLES `eventhandler_suite` WRITE;
/*!40000 ALTER TABLE `eventhandler_suite` DISABLE KEYS */;
INSERT INTO `eventhandler_suite` VALUES ('1fcc473a-2145-11e5-b8c6-005056c00008','1fcc4739-2145-11e5-b8c6-005056c00008','de67ff1e-2144-11e5-b8c6-005056c00008',10),('6b7e88af-e4ce-11e4-9c8d-70f395293eeb','3fac80ec-e2a2-11e4-9f87-cc52af76f1df','f2196058-e4cc-11e4-9c8d-70f395293eeb',10),('889dd4c2-e8c0-11e4-93b7-1c659df72b8d','889dd4ac-e8c0-11e4-93b7-1c659df72b8d','24e097f2-e4bf-11e4-9f87-cc52af76f1df',10),('98c24621-e8aa-11e4-93b7-1c659df72b8d','98c2453b-e8aa-11e4-93b7-1c659df72b8d','24e097f2-e4bf-11e4-9f87-cc52af76f1df',10),('e08c5eb9-e8ad-11e4-93b7-1c659df72b8d','e08c5dd3-e8ad-11e4-93b7-1c659df72b8d','24e097f2-e4bf-11e4-9f87-cc52af76f1df',10);
/*!40000 ALTER TABLE `eventhandler_suite` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:41
