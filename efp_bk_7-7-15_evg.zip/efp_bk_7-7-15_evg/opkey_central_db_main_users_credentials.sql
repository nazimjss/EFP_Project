CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_users_credentials`
--

DROP TABLE IF EXISTS `main_users_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_users_credentials` (
  `U_ID` varchar(63) NOT NULL,
  `Authentication_Provider` varchar(45) NOT NULL,
  `Remote_U_ID` varchar(255) NOT NULL,
  `Remote_Token` text,
  PRIMARY KEY (`U_ID`),
  UNIQUE KEY `Unique_Remote_U_ID` (`Remote_U_ID`),
  CONSTRAINT `FK_main_users_credentials_1` FOREIGN KEY (`U_ID`) REFERENCES `main_users` (`U_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_users_credentials`
--

LOCK TABLES `main_users_credentials` WRITE;
/*!40000 ALTER TABLE `main_users_credentials` DISABLE KEYS */;
INSERT INTO `main_users_credentials` VALUES ('3aaa2b0f-1645-11e5-97d1-68b599f9eec8','CresTech.OpKey.Authentication.Windows','CTECH_AD\\mohd.nazim','S-1-5-21-612894713-43423695-3737456308-2676'),('4e747358-13ec-11e5-8ce5-1c659df72b8d','CresTech.OpKey.Authentication.Windows','CTECH_AD\\babli.gupta','S-1-5-21-612894713-43423695-3737456308-9250'),('5c12b81c-0f58-11e5-a531-000c29356af5','CresTech.OpKey.Authentication.Windows','CTECH_AD\\amallik','S-1-5-21-612894713-43423695-3737456308-1316'),('6c469e6f-d39a-11e4-87a9-1c659df72b8d','CresTech.OpKey.Authentication.Windows','CTECH_AD\\vaibhav.tiwari','S-1-5-21-612894713-43423695-3737456308-1456'),('74fd9b3f-d39a-11e4-87a9-1c659df72b8d','CresTech.OpKey.Authentication.Windows','CTECH_AD\\monisha.gurjar','S-1-5-21-612894713-43423695-3737456308-5088'),('7a0dc048-d6ae-11e4-98c1-1c659df72b8d','CresTech.OpKey.Authentication.Windows','CTECH_AD\\vishal.sharma','S-1-5-21-612894713-43423695-3737456308-5072'),('7f96505f-d39a-11e4-87a9-1c659df72b8d','CresTech.OpKey.Authentication.Windows','CTECH_AD\\gaurav.satija','S-1-5-21-612894713-43423695-3737456308-4460'),('9547c00f-d39a-11e4-87a9-1c659df72b8d','CresTech.OpKey.Authentication.Windows','CTECH_AD\\ritesh.kumar','S-1-5-21-612894713-43423695-3737456308-1440'),('9bc0177f-d39a-11e4-87a9-1c659df72b8d','CresTech.OpKey.Authentication.Windows','CTECH_AD\\niharika.jain','S-1-5-21-612894713-43423695-3737456308-2710'),('eb30061d-df3d-11e4-98f6-1c659df72b8d','CresTech.OpKey.Authentication.Windows','CTECH_AD\\shipra.chauhan','S-1-5-21-612894713-43423695-3737456308-4954');
/*!40000 ALTER TABLE `main_users_credentials` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:49
