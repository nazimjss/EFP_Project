CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eventhandler_args`
--

DROP TABLE IF EXISTS `eventhandler_args`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventhandler_args` (
  `arg_id` varchar(64) NOT NULL,
  `ehandler_id` varchar(64) NOT NULL,
  `eparam_id` varchar(64) NOT NULL,
  `value` text,
  `Position` int(10) unsigned NOT NULL,
  PRIMARY KEY (`arg_id`),
  KEY `FK_eventhandler_args__main_event_params` (`eparam_id`),
  KEY `FK_eventhandler_args__eventhyandlers` (`ehandler_id`),
  CONSTRAINT `FK_eventhandler_args__eventhyandlers` FOREIGN KEY (`ehandler_id`) REFERENCES `eventhandlers` (`ehandler_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_eventhandler_args__main_event_params` FOREIGN KEY (`eparam_id`) REFERENCES `main_event_params` (`eparam_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventhandler_args`
--

LOCK TABLES `eventhandler_args` WRITE;
/*!40000 ALTER TABLE `eventhandler_args` DISABLE KEYS */;
INSERT INTO `eventhandler_args` VALUES ('15b60b88-e4cd-11e4-9c8d-70f395293eeb','f2196058-e4cc-11e4-9c8d-70f395293eeb','0674889e-7ce7-4f31-abec-78ce61e4ff24','Regulatory Compliance',0),('15b60b89-e4cd-11e4-9c8d-70f395293eeb','f2196058-e4cc-11e4-9c8d-70f395293eeb','7eed8b87-b1e1-4e28-8558-1d91bceddb39','0',1),('24e097f5-e4bf-11e4-9f87-cc52af76f1df','24e097f2-e4bf-11e4-9f87-cc52af76f1df','0674889e-7ce7-4f31-abec-78ce61e4ff24','Setup',0),('24e097f6-e4bf-11e4-9f87-cc52af76f1df','24e097f2-e4bf-11e4-9f87-cc52af76f1df','7eed8b87-b1e1-4e28-8558-1d91bceddb39','1',1),('de67ff21-2144-11e5-b8c6-005056c00008','de67ff1e-2144-11e5-b8c6-005056c00008','0674889e-7ce7-4f31-abec-78ce61e4ff24','CLIENT',0),('de67ff22-2144-11e5-b8c6-005056c00008','de67ff1e-2144-11e5-b8c6-005056c00008','7eed8b87-b1e1-4e28-8558-1d91bceddb39','0',1);
/*!40000 ALTER TABLE `eventhandler_args` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:43
