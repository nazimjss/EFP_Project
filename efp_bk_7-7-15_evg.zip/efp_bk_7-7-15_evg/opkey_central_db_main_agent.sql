CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_agent`
--

DROP TABLE IF EXISTS `main_agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_agent` (
  `Agent_ID` varchar(63) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Description` text,
  `Host` varchar(255) NOT NULL,
  `Port` int(10) unsigned NOT NULL,
  `Position` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`Agent_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_agent`
--

LOCK TABLES `main_agent` WRITE;
/*!40000 ALTER TABLE `main_agent` DISABLE KEYS */;
INSERT INTO `main_agent` VALUES ('0a15a42d-fab5-11e3-9351-f65b19bcb8c3','Cloud Agent','OpKey Execution Agent on Cloud to support On-Demand Executions','-host-address-is-taken-from-configuration-',0,1),('1e053c38-fab5-11e3-9351-f65b19bcb8c3','Local Agent','Agent on Local Machine','Localhost',80,2),('4ea32488-14d4-11e5-a533-000c29d5570a','Babli-VM Agent',NULL,'192.168.48.128',8090,4),('6d6197ee-166e-11e5-a53a-000c29c190fd','efp_Ashish',NULL,'192.168.136.128',8090,6),('6e3f5c23-14d4-11e5-bc86-005056c00008','Shipra_VM_Agent',NULL,'192.168.71.128',8090,4),('9a4c8920-1042-11e5-895c-005056c00008','Ankit-VM-agent',NULL,'xPeCC',8095,3),('9ce5d14d-1651-11e5-97d1-68b599f9eec8','nazimVm',NULL,'192.168.10.128',8090,5),('ccedcea1-18c7-11e5-9975-005056c00008','vishalVM',NULL,'192.168.92.128',8090,7);
/*!40000 ALTER TABLE `main_agent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:36
