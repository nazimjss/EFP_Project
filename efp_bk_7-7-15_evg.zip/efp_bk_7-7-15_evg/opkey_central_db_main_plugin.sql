CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_plugin`
--

DROP TABLE IF EXISTS `main_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_plugin` (
  `PluginID` varchar(63) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Version` varchar(20) NOT NULL,
  `Description` text,
  `VendorName` varchar(255) NOT NULL,
  `Icon` blob,
  `InstalledBy` varchar(63) NOT NULL,
  `InstalledOn` datetime NOT NULL,
  `InstalledOn_tz` varchar(255) NOT NULL,
  `KeywordSetVersion` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`PluginID`),
  KEY `FK_plugin_users` (`InstalledBy`),
  CONSTRAINT `FK_plugin_users` FOREIGN KEY (`InstalledBy`) REFERENCES `main_users` (`U_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_plugin`
--

LOCK TABLES `main_plugin` WRITE;
/*!40000 ALTER TABLE `main_plugin` DISABLE KEYS */;
INSERT INTO `main_plugin` VALUES ('1f970044-13ce-4728-8593-c52377f21c64','Selenium WebDriver','1.9.0.1721','Supports Functional testing using selenium-2.45.0\n  \n  -.-.-.-.-.--.--.-.-.-.-.--.-TESTED-.-.-.-.-.--.--.-.-.-.-.--.-\n  FireFox  :  version 16 to 36\n  Chrome  :  version 16 to 41\n  InternetExplorer  :  version 8 to 11*\n\n  |_ IE DriverServer Executable \n  http://selenium-release.storage.googleapis.com/index.html\n  |_ ChromeDriver Executable : \n  http://chromedriver.storage.googleapis.com/index.html\n  \n*Note \nCurrently supports for IE11 On windows7 32 bit architecture only due to the limitation of Selenium. \n https://code.google.com/p/selenium/issues/detail?id=6511  	\n  	\n  ','CresTech',NULL,'e23faacf-f26f-480c-bbdc-f504276743a8','2014-10-13 08:04:49','Nepal Standard Time',1),('677e472d-c601-42ab-8d99-02d2bee029d5','Sikuli','2.0.0.1654','Sikuli plugin for OpKey.  \n  Sikuli automates anything you see on the screen.\n  It uses image recognition to identify and control GUI components. It is useful when there is no easy access to a GUI\'s internal or source code.\n  The plugin also supports some basic OCR/Text Recognition.','CresTech',NULL,'e23faacf-f26f-480c-bbdc-f504276743a8','2014-10-13 08:04:51','Nepal Standard Time',5),('740cb557-bd1d-4a6f-a752-2a898d0ef604','Robotium','1.1.7.0','Supports mobile automation testing using Robotium.','CresTech',NULL,'e23faacf-f26f-480c-bbdc-f504276743a8','2014-10-13 08:04:46','Nepal Standard Time',17),('c1c25e0b-c761-46c1-956f-776642945688','UFT','0.1.0.1523','Supports Functional testing using QTP.','CresTech',NULL,'e23faacf-f26f-480c-bbdc-f504276743a8','2014-10-13 08:04:54','Nepal Standard Time',1),('ed060d45-4235-4f04-9aa8-6ce4fb435c39','Appium','0.10.0.1726','Supports Functional testing using Appium on Android as well as iOS Phone/Simulator.\n  \n Supports Functional testing using AppiumVersion 1.3.4.1\n  ','CresTech',NULL,'e23faacf-f26f-480c-bbdc-f504276743a8','2014-10-13 08:04:43','Nepal Standard Time',21);
/*!40000 ALTER TABLE `main_plugin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:27
