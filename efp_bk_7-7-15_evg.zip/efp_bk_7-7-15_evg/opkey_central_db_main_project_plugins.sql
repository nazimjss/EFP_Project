CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_project_plugins`
--

DROP TABLE IF EXISTS `main_project_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_project_plugins` (
  `P_ID` varchar(63) NOT NULL,
  `PluginID` varchar(63) NOT NULL,
  PRIMARY KEY (`P_ID`,`PluginID`),
  KEY `FK_main_project_plugins_Plugin` (`PluginID`),
  CONSTRAINT `FK_main_project_plugins_Plugin` FOREIGN KEY (`PluginID`) REFERENCES `main_plugin` (`PluginID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_main_project_plugins_Project` FOREIGN KEY (`P_ID`) REFERENCES `main_projectlist` (`P_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_project_plugins`
--

LOCK TABLES `main_project_plugins` WRITE;
/*!40000 ALTER TABLE `main_project_plugins` DISABLE KEYS */;
INSERT INTO `main_project_plugins` VALUES ('1c046676-0f5d-11e5-a533-000c29e97660','1f970044-13ce-4728-8593-c52377f21c64'),('411aad8f-d39a-11e4-87a9-1c659df72b8d','1f970044-13ce-4728-8593-c52377f21c64'),('439dd8e8-0f58-11e5-a531-000c29356af5','1f970044-13ce-4728-8593-c52377f21c64'),('f45ec806-13f5-11e5-bc30-005056c00008','1f970044-13ce-4728-8593-c52377f21c64'),('1c046676-0f5d-11e5-a533-000c29e97660','677e472d-c601-42ab-8d99-02d2bee029d5'),('411aad8f-d39a-11e4-87a9-1c659df72b8d','677e472d-c601-42ab-8d99-02d2bee029d5'),('439dd8e8-0f58-11e5-a531-000c29356af5','677e472d-c601-42ab-8d99-02d2bee029d5'),('f45ec806-13f5-11e5-bc30-005056c00008','677e472d-c601-42ab-8d99-02d2bee029d5'),('1c046676-0f5d-11e5-a533-000c29e97660','740cb557-bd1d-4a6f-a752-2a898d0ef604'),('439dd8e8-0f58-11e5-a531-000c29356af5','740cb557-bd1d-4a6f-a752-2a898d0ef604'),('f45ec806-13f5-11e5-bc30-005056c00008','740cb557-bd1d-4a6f-a752-2a898d0ef604'),('f45ec806-13f5-11e5-bc30-005056c00008','c1c25e0b-c761-46c1-956f-776642945688'),('1c046676-0f5d-11e5-a533-000c29e97660','ed060d45-4235-4f04-9aa8-6ce4fb435c39'),('439dd8e8-0f58-11e5-a531-000c29356af5','ed060d45-4235-4f04-9aa8-6ce4fb435c39'),('f45ec806-13f5-11e5-bc30-005056c00008','ed060d45-4235-4f04-9aa8-6ce4fb435c39');
/*!40000 ALTER TABLE `main_project_plugins` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:29
