CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eventhandlers`
--

DROP TABLE IF EXISTS `eventhandlers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventhandlers` (
  `ehandler_id` varchar(64) NOT NULL,
  `event_id` varchar(64) NOT NULL COMMENT 'trigger',
  `postevent_enum` varchar(100) NOT NULL,
  PRIMARY KEY (`ehandler_id`),
  KEY `fk_eventhandlers_main_events1` (`event_id`),
  CONSTRAINT `fk_eventhandlers_main_events1` FOREIGN KEY (`event_id`) REFERENCES `main_events` (`event_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_eventhandlers__meta_eventhandler` FOREIGN KEY (`ehandler_id`) REFERENCES `meta_eventhandler` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventhandlers`
--

LOCK TABLES `eventhandlers` WRITE;
/*!40000 ALTER TABLE `eventhandlers` DISABLE KEYS */;
INSERT INTO `eventhandlers` VALUES ('24e097f2-e4bf-11e4-9f87-cc52af76f1df','dbbe18c6-57e6-407f-9851-cb83ef6dad8e','ProceedToNextStep'),('de67ff1e-2144-11e5-b8c6-005056c00008','dbbe18c6-57e6-407f-9851-cb83ef6dad8e','ProceedToNextStep'),('f2196058-e4cc-11e4-9c8d-70f395293eeb','dbbe18c6-57e6-407f-9851-cb83ef6dad8e','ProceedToNextStep');
/*!40000 ALTER TABLE `eventhandlers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:28
