CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_users`
--

DROP TABLE IF EXISTS `main_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_users` (
  `U_ID` varchar(40) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Salt` varchar(255) NOT NULL,
  `email_ID` varchar(255) DEFAULT NULL,
  `Is_Enabled` tinyint(1) NOT NULL DEFAULT '1',
  `CreationDate` datetime NOT NULL,
  `CreationDate_tz` varchar(255) NOT NULL,
  `CreatedBy` varchar(63) NOT NULL,
  `LastModificationDate` datetime NOT NULL,
  `LastModificationDate_tz` varchar(255) NOT NULL,
  `LastModifiedBy` varchar(63) NOT NULL,
  `Is_SuperAdmin` tinyint(1) NOT NULL,
  PRIMARY KEY (`U_ID`),
  UNIQUE KEY `Unique_UserName` (`UserName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_users`
--

LOCK TABLES `main_users` WRITE;
/*!40000 ALTER TABLE `main_users` DISABLE KEYS */;
INSERT INTO `main_users` VALUES ('204e7e4f-ddf1-11e4-8c23-1c659df72b8d','Sushila','Sushila','DDiMgiYdDo9nbsbOLmT7XCtZSu9/dssfDZ7YbjbJ4DzF7Nj9a6EstrHLAEImzewb','/w9MrZa05tc6',NULL,1,'2015-04-08 13:12:23','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-04-08 13:12:23','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('358d1df6-ddf1-11e4-8c23-1c659df72b8d','Todd','Todd','MRxaNqq1uN3VSoKCjHdVMFPvx8KQ0t5ilmsAlOEwKlIkixS9jXVgxGyw2WUZxyzz','62eV1DQV+XJX',NULL,1,'2015-04-08 13:12:59','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-04-08 13:12:59','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('3aaa2b0f-1645-11e5-97d1-68b599f9eec8','Mohd Nazim','nazim','S+YM3oNicybPwvOdho6o3QtiFh7mFI4FbraXossyW2mmVGiU139jRYLD3Xz0Myjw','yOSPRlshptTO','mohd.nazim@crestechglobal.com',1,'2015-06-19 05:36:54','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-06-19 05:36:55','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('4e747358-13ec-11e5-8ce5-1c659df72b8d','babli','babli','v2wBI5afUaZ5wnY/zqNXEXlGyq58cY9u8iQEUYqcEwa9lsdlmvCh/v3z9PLMBMEh','sdpDd+uJ7nJD',NULL,1,'2015-06-16 05:55:28','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-06-16 05:55:28','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('5c12b81c-0f58-11e5-a531-000c29356af5','Ankit','Ankit Gupta','egEpx4SYSEbCSNTaiRnXTWxiENtuhm3l1nbMRXgBTgDodKs7qBKOPDKA42fFSaSu','97oPi8E1EB3p','Ankit.gupta@crestechglobal.com',1,'2015-06-10 10:06:27','Eastern Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-06-17 07:02:54','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('6c469e6f-d39a-11e4-87a9-1c659df72b8d','Vaibhav','Vaibhav','MX3MqxmOCdCjVPUWJbcBSWPXldQRPTbdFfZ5PDOySA9ZCcAQeR5c7wP4Ef107W5e','H/6E3MPjxJdd',NULL,1,'2015-03-26 09:28:13','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-03-26 09:28:13','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('74fd9b3f-d39a-11e4-87a9-1c659df72b8d','Monisha','Monisha','9OjG3SNb4X97rHy1W2LwnSQigOrDZ82kqO8crhCydozPisXtLlp/mpvNaV7Gicug','GrRNJsc8KPvL',NULL,1,'2015-03-26 09:28:27','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-03-26 09:28:27','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('7a0dc048-d6ae-11e4-98c1-1c659df72b8d','Vishal','Vishal','iqeXm2Lz8tK5EZxLyqwizGrboyImhZC01jSKs1R/cb3FCYbYTYi0k5fOGidvjAbh','SfwRIC3Jqpi3',NULL,1,'2015-03-30 07:29:20','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-05-01 04:18:01','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('7f96505f-d39a-11e4-87a9-1c659df72b8d','Gaurav','Gaurav','GOOo6KZLNk0E2hp8LgVKS5D9y1slZk9x0exaVpIAoKK5aNjEkd0XIvdboKwZAlsi','UfSynHJM0J/j',NULL,1,'2015-03-26 09:28:45','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-03-26 09:28:45','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('9547c00f-d39a-11e4-87a9-1c659df72b8d','Ritesh','Ritesh','P1WHqHZ8H3E7QVwZPDaoJmfWpgqWv97iHlaPVh1Zjd/788Fs7geP3EAK64RJasA8','iirXAFfCJ2ji',NULL,1,'2015-03-26 09:29:22','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-03-26 09:29:22','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('95a7c238-d6ad-11e4-98c1-1c659df72b8d','Ashish','Ashish','cE4pOmAgJcMSwJbBnqJF6Hd04yQQ/d+pVnHheUXWc81icQyxr4sA7CUgJS5455n6','yWQOCxvRahHe',NULL,1,'2015-03-30 07:22:56','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-06-19 10:30:30','Eastern Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('9bc0177f-d39a-11e4-87a9-1c659df72b8d','Niharika','Niharika','fU29Q+uWlKD4BQLpAvS/GS3Lmq31DFPy388jDXCaK5Yh7Z+6tzyTeuq2ld4rYIrN','pBMrQggSy9aD',NULL,1,'2015-03-26 09:29:32','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-03-26 09:29:32','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('e23faacf-f26f-480c-bbdc-f504276743a8','OpKey Administrator','admin','nKaUqQKFwDRDLJVQQht7nb1cD0tmc/BfbbzlgFK6IOQkgEGVbujJouyfECkM3AeC','',NULL,1,'2012-11-27 11:23:48','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2012-11-27 11:23:48','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',1),('eb30061d-df3d-11e4-98f6-1c659df72b8d','Shipra','Shipra','5JWotVLAYdX+8rrKpaZUbrWRx7w+KAg2wltvrVCEZo3iVAx3bBc0K89SFOxhRh0D','M1Hw2itzNeBw',NULL,1,'2015-04-10 04:54:32','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-04-10 04:54:32','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0),('ff5c42b4-0f5c-11e5-a533-000c29e97660','shipra','Shipra chauhan','y5eRZRzeA4xikLJwqJtIf+C9PsIm0bsykNYH9aPvYKA13+Q2XsdxdJ1vQGG1NZT7','GOi8fZmnrNfu','shipra.chauhan@crestechglobal.com',1,'2015-06-10 10:39:37','Eastern Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2015-06-10 10:39:37','Eastern Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',0);
/*!40000 ALTER TABLE `main_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:37
