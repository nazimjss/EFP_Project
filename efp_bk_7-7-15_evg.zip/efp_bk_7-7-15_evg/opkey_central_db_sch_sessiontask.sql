CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sch_sessiontask`
--

DROP TABLE IF EXISTS `sch_sessiontask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sch_sessiontask` (
  `SessionTask_ID` varchar(63) NOT NULL,
  `Job_ID` varchar(63) NOT NULL,
  `Build_ID` varchar(63) NOT NULL,
  `Suite_ID` varchar(63) NOT NULL,
  `DefaultPluginID` varchar(63) DEFAULT NULL,
  `ExpectedSessionName` varchar(255) NOT NULL,
  `DefaultStepTimeout` int(10) unsigned NOT NULL,
  `SnapshotQuality_Enum` varchar(20) NOT NULL,
  `SnapshotFrequency_Enum` varchar(45) NOT NULL,
  `RunAgent_ID` varchar(63) NOT NULL,
  `Position` int(10) unsigned NOT NULL,
  `Session_ID` varchar(63) DEFAULT NULL,
  `SendReportType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`SessionTask_ID`),
  KEY `FK_Sch_SessionTask_main_Agent` (`RunAgent_ID`),
  KEY `FK_sch_sessiontask_Job` (`Job_ID`),
  KEY `FK_sch_sessiontask_ex_Build` (`Build_ID`),
  KEY `FK_sch_sessiontask_ex_Suite` (`Suite_ID`),
  KEY `FK_sch_sessiontask_ex_plugin` (`DefaultPluginID`),
  KEY `FK_sch_sessiontask_Session` (`Session_ID`),
  CONSTRAINT `FK_sch_sessiontask_ex_Build` FOREIGN KEY (`Build_ID`) REFERENCES `ex_build` (`Build_ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_sch_sessiontask_ex_plugin` FOREIGN KEY (`DefaultPluginID`) REFERENCES `main_plugin` (`PluginID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_sch_sessiontask_ex_Suite` FOREIGN KEY (`Suite_ID`) REFERENCES `meta_suite` (`ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_sch_sessiontask_Job` FOREIGN KEY (`Job_ID`) REFERENCES `sch_job` (`Job_Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_Sch_SessionTask_main_Agent` FOREIGN KEY (`RunAgent_ID`) REFERENCES `main_agent` (`Agent_ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_sch_sessiontask_Session` FOREIGN KEY (`Session_ID`) REFERENCES `ex_session` (`Session_ID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sch_sessiontask`
--

LOCK TABLES `sch_sessiontask` WRITE;
/*!40000 ALTER TABLE `sch_sessiontask` DISABLE KEYS */;
/*!40000 ALTER TABLE `sch_sessiontask` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:45
