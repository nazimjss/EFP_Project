CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `old_flow_step_input_arguments`
--

DROP TABLE IF EXISTS `old_flow_step_input_arguments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_flow_step_input_arguments` (
  `Flow_Step_IA_ID` varchar(63) NOT NULL,
  `Version_No` int(10) NOT NULL,
  `Flow_StepID` varchar(63) NOT NULL,
  `Component_IP_ID` varchar(63) DEFAULT NULL,
  `Keyword_IP_ID` varchar(63) DEFAULT NULL,
  `WebMethod_IP_ID` varchar(63) DEFAULT NULL,
  `Datasource` varchar(45) NOT NULL,
  `StaticValue` text,
  `Flow_Step_OA_ID` varchar(63) DEFAULT NULL,
  `StaticObjectID` varchar(63) DEFAULT NULL,
  `DataRepositoryColumnID` varchar(63) DEFAULT NULL,
  `DRColumnBindingMode` varchar(45) DEFAULT NULL,
  `GlobalVariable_ID` varchar(63) DEFAULT NULL,
  PRIMARY KEY (`Flow_Step_IA_ID`,`Version_No`) USING BTREE,
  KEY `DesignStepID` (`Flow_StepID`) USING BTREE,
  KEY `FK_flow_step_input_arguments_component_IP` (`Component_IP_ID`),
  KEY `FK_flow_step_input_arguments_KeywordIP` (`Keyword_IP_ID`),
  KEY `FK_flow_step_input_arguments_step_OA` (`Flow_Step_OA_ID`),
  KEY `FK_flow_step_input_arguments_objectID` (`StaticObjectID`),
  KEY `FK_flow_step_input_arguments_DRColumn` (`DataRepositoryColumnID`),
  KEY `FK_old_flow_step_input_arguments_GlobalVariable` (`GlobalVariable_ID`),
  KEY `FK_old_flow_step_input_arguments_ws_method_ip` (`WebMethod_IP_ID`),
  CONSTRAINT `FK_old_flow_step_input_arguments_component_IP` FOREIGN KEY (`Component_IP_ID`) REFERENCES `component_input_parameters` (`IP_ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_old_flow_step_input_arguments_DRColumn` FOREIGN KEY (`DataRepositoryColumnID`) REFERENCES `dr_columns` (`Column_ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_old_flow_step_input_arguments_GlobalVariable` FOREIGN KEY (`GlobalVariable_ID`) REFERENCES `global_variables` (`GV_ID`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_old_flow_step_input_arguments_KeywordIP` FOREIGN KEY (`Keyword_IP_ID`) REFERENCES `main_keywordarguments` (`ArgID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_old_flow_step_input_arguments_objectID` FOREIGN KEY (`StaticObjectID`) REFERENCES `or_objects` (`Object_ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_old_flow_step_input_arguments_old_flowStep` FOREIGN KEY (`Flow_StepID`) REFERENCES `old_flow_design_steps` (`Flow_StepID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_old_flow_step_input_arguments_step_OA` FOREIGN KEY (`Flow_Step_OA_ID`) REFERENCES `old_flow_step_output_arguments` (`Flow_Step_OA_ID`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `FK_old_flow_step_input_arguments_ws_method_ip` FOREIGN KEY (`WebMethod_IP_ID`) REFERENCES `ws_method_input_parameters` (`IP_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_flow_step_input_arguments`
--

LOCK TABLES `old_flow_step_input_arguments` WRITE;
/*!40000 ALTER TABLE `old_flow_step_input_arguments` DISABLE KEYS */;
/*!40000 ALTER TABLE `old_flow_step_input_arguments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:37
