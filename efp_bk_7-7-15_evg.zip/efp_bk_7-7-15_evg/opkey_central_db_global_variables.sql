CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `global_variables`
--

DROP TABLE IF EXISTS `global_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global_variables` (
  `GV_ID` varchar(63) NOT NULL,
  `P_ID` varchar(63) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Value` text,
  `Position` int(10) unsigned NOT NULL,
  `DataType` varchar(45) NOT NULL DEFAULT 'String',
  PRIMARY KEY (`GV_ID`),
  UNIQUE KEY `Unique` (`Name`,`P_ID`),
  UNIQUE KEY `Unique2` (`P_ID`,`Position`),
  CONSTRAINT `FK_global_variables_Project` FOREIGN KEY (`P_ID`) REFERENCES `main_projectlist` (`P_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_variables`
--

LOCK TABLES `global_variables` WRITE;
/*!40000 ALTER TABLE `global_variables` DISABLE KEYS */;
INSERT INTO `global_variables` VALUES ('0035964b-1a68-11e5-b47c-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','GetControlText2Path','C:\\Autoit_script\\keywords\\GetText.exe',9,'String'),('076031e3-e5aa-11e4-9bd3-005056c00008','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA216_User','CT_CTA216',19,'String'),('0e464fe1-134c-11e5-a1b6-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','Default Browser','Mozilla Firefox',1,'String'),('26e8216b-10c0-11e5-8cef-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','DC_Console',NULL,31,'String'),('2e772be9-e587-11e4-8ce1-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','Global_Account_Type','catqa',14,'String'),('2e772bea-e587-11e4-8ce1-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','Global_UserName','spaliwal',15,'String'),('321d5ead-1a3b-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','imagePathA','C:\\Tips\\config\\images',2,'String'),('38f6c3fa-e587-11e4-8ce1-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','Global_Password','Password1',16,'String'),('3b0394c4-1a3b-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','imagePathB','C:\\Tips\\backUpImages',3,'String'),('46b04dea-1a5d-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','resultFilePath','C:\\Result\\Result2.txt',7,'String'),('4dd96ed5-1a5b-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','eFingerPrintDirPath','C:\\eFingerprint',4,'String'),('52c7e3b9-e435-11e4-8cd7-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA455_Device_Name',NULL,9,'String'),('5828676d-e8c1-11e4-929e-005056c00008','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA531_Rowcount_DevieVoc',NULL,21,'String'),('5bebe0cb-e4be-11e4-b8bd-00265543ee0a','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA171_UserName',NULL,12,'String'),('6189d4b2-05c4-11e5-8561-cc52afcd8ed6','411aad8f-d39a-11e4-87a9-1c659df72b8d','Fetching_Item_Xml','0',30,'Integer'),('62ae01b7-d39d-11e4-87a9-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','Default Browser','Mozilla Firefox',1,'String'),('660f0af1-ef2c-11e4-883f-50e549e7d47e','411aad8f-d39a-11e4-87a9-1c659df72b8d','List_Range_Validation','0',27,'Integer'),('67b79b63-0387-11e5-982b-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','PDF_DownLoad_Path','C:\\Users\\niharika.jain\\Downloads\\',28,'String'),('7054d874-1b08-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','citaDelURL','https://dev-crestech.systechcitadel.com/',12,'String'),('75a50203-1fc4-11e5-94b0-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','CheckBoxPath','C:\\Autoit_script\\keywords\\CheckBox.exe',20,'String'),('78a48c9f-1b17-11e5-8b92-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','CheckImageInZip','C:\\Autoit_script\\keywords\\ZipImage.jar',16,'String'),('7b74e949-ed72-11e4-b3a2-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','Global_File_Path','D:\\SampleXML\\',22,'String'),('7bcc7640-1fb4-11e5-8c9d-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','Fetch_XML_Value','0',32,'Integer'),('7c0436b9-1b0b-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','getTextExePath','C:\\Autoit_script\\keywords\\GetText.exe',15,'String'),('7cdbde8c-1e32-11e5-933e-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','winTitleExe','C:\\Autoit_script\\keywords\\WinTitle.exe',18,'String'),('80d6e26d-d796-11e4-982c-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA172-294_Password',NULL,6,'String'),('8454bad4-e5c6-11e4-b882-d0df9a3c6e01','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA191_username','ct_permission',20,'String'),('8714f1d9-1b08-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','citaDelUserName','sushila',13,'String'),('876accf4-1a5b-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','clickExePath','C:\\Autoit_script\\keywords\\click2.exe',5,'String'),('876accf5-1a5b-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','typeExePath','C:\\Autoit_script\\keywords\\typetext2.exe',6,'String'),('89da4d9c-1be4-11e5-8a96-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','DropDownExePath','C:\\Autoit_script\\keywords\\dropdown.exe',17,'String'),('92d50ed9-1b08-11e5-81e3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','citaDelPassword','India@123',14,'String'),('93234a16-e1c0-11e4-90aa-cc52af76f1df','411aad8f-d39a-11e4-87a9-1c659df72b8d','Global_Application_URL','https://systech-us-east.systechcitadel.com',8,'String'),('9be1b82a-1e64-11e5-a6a3-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','machineNamePath','C:\\Autoit_script\\keywords\\MachineName.jar',19,'String'),('a0dd96c4-e4dc-11e4-8cc0-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA171_Password',NULL,13,'String'),('a4b147dc-e58b-11e4-8ce1-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','All_Permission_User','All_per',17,'String'),('a4b147dd-e58b-11e4-8ce1-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','No_Permission_User','No_per',18,'String'),('a72da520-df3f-11e4-bfb6-005056c00008','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA181_Row_Count for Reueue',NULL,7,'Integer'),('ae722235-e435-11e4-8cd7-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA455_SGLN_Value',NULL,10,'String'),('b42daa57-1a5d-11e5-b47c-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','WindowClosePath','C:\\Autoit_script\\keywords\\winclose.exe',8,'String'),('c47f9c10-d787-11e4-982c-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA172-294_UserName',NULL,5,'String'),('d53e5013-23a4-11e5-99fc-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','RadioButtonPath','C:\\Autoit_script\\keywords\\RadioButton.exe',22,'String'),('d7bfe61c-e4bd-11e4-b8bd-00265543ee0a','411aad8f-d39a-11e4-87a9-1c659df72b8d','Global_Sample_XML_File_Path_Inbound_Job','D:\\SampleXML\\systech-small-file.xml',11,'String'),('d8a2a565-eda2-11e4-b3a2-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','SSCC_EPC_API_Key',NULL,23,'String'),('d8a2a566-eda2-11e4-b3a2-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','SSCC_GS1_API_Key',NULL,24,'String'),('d8a2a567-eda2-11e4-b3a2-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','SGTIN_EPC_API_Key',NULL,25,'String'),('d8a2a568-eda2-11e4-b3a2-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','SGTIN_GS1_API_Key',NULL,26,'String'),('da550bdf-1a6a-11e5-b47c-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','ClearDirPath','C:\\Autoit_script\\keywords\\DirClean.jar',10,'String'),('e2526851-23ba-11e5-883b-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','ObjectExistPath','C:\\Autoit_script\\keywords\\objectexists.exe',23,'String'),('e9e9780c-1af1-11e5-adb8-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','CheckZipPath','C:\\Autoit_script\\keywords\\CheckZip.jar',11,'String'),('eb73fecf-050c-11e5-98ff-1c659df72b8d','411aad8f-d39a-11e4-87a9-1c659df72b8d','CTA1341_Transaction_Output',NULL,29,'String'),('ee1d28dd-2172-11e5-a0c8-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5','ConfigFilePath','C:\\tips\\config\\EFingerprintTransfer.config',21,'String'),('f8e4eb6c-13f6-11e5-bc30-005056c00008','f45ec806-13f5-11e5-bc30-005056c00008','Default Browser','Mozilla Firefox',1,'String');
/*!40000 ALTER TABLE `global_variables` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:38
