CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eventhandler_step_args`
--

DROP TABLE IF EXISTS `eventhandler_step_args`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `eventhandler_step_args` (
  `EHStepArg_ID` varchar(64) NOT NULL,
  `EHStep_ID` varchar(64) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `value` text,
  `FlowID` varchar(64) DEFAULT NULL,
  `DataSheet_ID` varchar(64) DEFAULT NULL,
  `Position` int(10) unsigned NOT NULL,
  PRIMARY KEY (`EHStepArg_ID`) USING BTREE,
  KEY `FK_eventhandler_step_args__eventhandler_steps` (`EHStep_ID`) USING BTREE,
  KEY `FK_eventhandler_step_args_meta_flow_ID` (`FlowID`),
  KEY `FK_eventhandler_step_args_Datasheet_Datasheet_ID` (`DataSheet_ID`),
  CONSTRAINT `FK_eventhandler_step_args_Datasheet_Datasheet_ID` FOREIGN KEY (`DataSheet_ID`) REFERENCES `datasheet` (`Datasheet_ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_eventhandler_step_args_eventhandler_step_EHStepID` FOREIGN KEY (`EHStep_ID`) REFERENCES `eventhandler_steps` (`EHStep_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_eventhandler_step_args_meta_flow_ID` FOREIGN KEY (`FlowID`) REFERENCES `meta_flow` (`ID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventhandler_step_args`
--

LOCK TABLES `eventhandler_step_args` WRITE;
/*!40000 ALTER TABLE `eventhandler_step_args` DISABLE KEYS */;
INSERT INTO `eventhandler_step_args` VALUES ('223078f9-e4cd-11e4-9c8d-70f395293eeb','223078f8-e4cd-11e4-9c8d-70f395293eeb','KeyToPress','Esc',NULL,NULL,0),('223078fa-e4cd-11e4-9c8d-70f395293eeb','223078f8-e4cd-11e4-9c8d-70f395293eeb','KeyPressRepetition',NULL,NULL,NULL,1),('cc0e4ca6-e4bf-11e4-9f87-cc52af76f1df','cc0e4ca5-e4bf-11e4-9f87-cc52af76f1df','KeyToPress','Enter',NULL,NULL,0),('cc0e4ca7-e4bf-11e4-9f87-cc52af76f1df','cc0e4ca5-e4bf-11e4-9f87-cc52af76f1df','KeyPressRepetition','1',NULL,NULL,1),('ea871ec9-2144-11e5-b8c6-005056c00008','ea871ec8-2144-11e5-b8c6-005056c00008','KeyToPress','Enter',NULL,NULL,0),('ea871eca-2144-11e5-b8c6-005056c00008','ea871ec8-2144-11e5-b8c6-005056c00008','KeyPressRepetition','1',NULL,NULL,1);
/*!40000 ALTER TABLE `eventhandler_step_args` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:39
