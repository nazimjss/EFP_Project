CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `old_flow_design_steps`
--

DROP TABLE IF EXISTS `old_flow_design_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `old_flow_design_steps` (
  `Flow_StepID` varchar(63) NOT NULL,
  `Flow_ID` varchar(63) NOT NULL,
  `Component_ID` varchar(63) DEFAULT NULL,
  `KeywordID` varchar(63) DEFAULT NULL,
  `WebMethod_ID` varchar(63) DEFAULT NULL,
  `ContinueOnError` tinyint(1) NOT NULL,
  `WantSnapshot` tinyint(1) NOT NULL,
  `IsNegative` tinyint(1) NOT NULL,
  `ShouldRun` tinyint(1) NOT NULL DEFAULT '1',
  `Version_No` int(11) NOT NULL,
  `Comment` text,
  `Position` int(11) NOT NULL,
  `Group_ID` varchar(63) DEFAULT NULL,
  PRIMARY KEY (`Flow_StepID`,`Version_No`) USING BTREE,
  KEY `FLOW_ID` (`Flow_ID`) USING BTREE,
  KEY `Component` (`Component_ID`),
  KEY `FK_old_flow_design_steps_KeywordID` (`KeywordID`),
  KEY `FK_old_flow_design_steps_ws_methods` (`WebMethod_ID`),
  CONSTRAINT `FK_old_flow_design_steps_KeywordID` FOREIGN KEY (`KeywordID`) REFERENCES `main_keywords` (`KeywordID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_old_flow_design_steps_ws_methods` FOREIGN KEY (`WebMethod_ID`) REFERENCES `ws_methods` (`Method_ID`) ON UPDATE CASCADE,
  CONSTRAINT `flow_design_steps_old_meta_components` FOREIGN KEY (`Component_ID`) REFERENCES `meta_component` (`ID`) ON UPDATE CASCADE,
  CONSTRAINT `flow_design_steps_old_meta_flow` FOREIGN KEY (`Flow_ID`) REFERENCES `old_meta_flow` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `old_flow_design_steps`
--

LOCK TABLES `old_flow_design_steps` WRITE;
/*!40000 ALTER TABLE `old_flow_design_steps` DISABLE KEYS */;
/*!40000 ALTER TABLE `old_flow_design_steps` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:29
