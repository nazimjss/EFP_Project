CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_roles`
--

DROP TABLE IF EXISTS `main_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_roles` (
  `R_ID` varchar(63) NOT NULL,
  `RoleName` varchar(255) NOT NULL,
  `CreationDate` datetime NOT NULL,
  `CreationDate_tz` varchar(255) NOT NULL,
  `CreatedBy` varchar(63) NOT NULL,
  `LastModificationDate` datetime NOT NULL,
  `LastModificationDate_tz` varchar(255) NOT NULL,
  `LastModifiedBy` varchar(63) NOT NULL,
  `IsSystemDefined` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`R_ID`),
  UNIQUE KEY `Unique_RoleName` (`RoleName`),
  KEY `FK_main_roles_users` (`CreatedBy`),
  CONSTRAINT `FK_main_roles_users` FOREIGN KEY (`CreatedBy`) REFERENCES `main_users` (`U_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_roles`
--

LOCK TABLES `main_roles` WRITE;
/*!40000 ALTER TABLE `main_roles` DISABLE KEYS */;
INSERT INTO `main_roles` VALUES ('1fd6da72-6904-4c16-aee3-11d3a7dfc3e3','Author','2013-06-11 19:13:39','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2013-06-11 19:13:39','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',1),('648e161b-77bc-45f4-b069-693e26cb827f','Runner','2013-06-11 19:13:46','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2013-06-11 19:13:46','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',1),('9a5f8f7d-cb76-450c-9f08-3f065cdd68a7','BA','2013-06-11 19:13:51','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2013-06-11 19:13:51','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',1),('ec61eed2-33c9-4a69-bfc7-2324fbc70a70','Project Admin','2013-06-11 19:13:30','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','2013-06-11 19:13:30','Indian Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8',1);
/*!40000 ALTER TABLE `main_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:48
