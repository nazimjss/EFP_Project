CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `meta_eventhandler`
--

DROP TABLE IF EXISTS `meta_eventhandler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `meta_eventhandler` (
  `ID` varchar(63) NOT NULL,
  `P_ID` varchar(63) NOT NULL,
  `Version_No` int(10) unsigned NOT NULL DEFAULT '1',
  `Name` varchar(255) NOT NULL,
  `IsFolder` tinyint(1) NOT NULL,
  `Description` text,
  `ParentId` varchar(63) DEFAULT NULL,
  `CreationDate` datetime NOT NULL,
  `CreationDate_tz` varchar(255) NOT NULL,
  `CreatedBy` varchar(63) NOT NULL,
  `ModifiedOn` datetime NOT NULL,
  `ModifiedOn_tz` varchar(255) NOT NULL,
  `ModifiedBy` varchar(63) NOT NULL,
  `Position` int(11) NOT NULL,
  `SpecializedSubType` varchar(45) DEFAULT NULL,
  `LockedBy` varchar(63) DEFAULT NULL,
  `LockedOn` datetime DEFAULT NULL,
  `LockedOn_tz` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NameUnique` (`Name`,`ParentId`) USING BTREE,
  KEY `FK_meta_or_users` (`CreatedBy`),
  KEY `FK_meta_or_users2` (`ModifiedBy`),
  KEY `FK_meta_or_users3` (`LockedBy`),
  KEY `FK_meta_or_Project` (`P_ID`),
  KEY `FK_meta_or_self` (`ParentId`),
  CONSTRAINT `FK_meta_eventhandler_Project` FOREIGN KEY (`P_ID`) REFERENCES `main_projectlist` (`P_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_meta_eventhandler_self` FOREIGN KEY (`ParentId`) REFERENCES `meta_or` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_meta_eventhandler_users` FOREIGN KEY (`CreatedBy`) REFERENCES `main_users` (`U_ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_meta_eventhandler_users2` FOREIGN KEY (`ModifiedBy`) REFERENCES `main_users` (`U_ID`) ON UPDATE CASCADE,
  CONSTRAINT `FK_meta_eventhandler_users3` FOREIGN KEY (`LockedBy`) REFERENCES `main_users` (`U_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meta_eventhandler`
--

LOCK TABLES `meta_eventhandler` WRITE;
/*!40000 ALTER TABLE `meta_eventhandler` DISABLE KEYS */;
INSERT INTO `meta_eventhandler` VALUES ('24e097f2-e4bf-11e4-9f87-cc52af76f1df','411aad8f-d39a-11e4-87a9-1c659df72b8d',1,'Handle Invalid Opcode PopUp',0,'{\\rtf1\\deff0{\\fonttbl{\\f0 Calibri;}}{\\colortbl ;\\red0\\green0\\blue255 ;}{\\*\\defchp \\fs22}{\\*\\listoverridetable}{\\stylesheet {\\ql\\fs22 Normal;}{\\*\\cs1\\fs22 Default Paragraph Font;}{\\*\\cs2\\sbasedon1\\fs22 Line Number;}{\\*\\cs3\\ul\\fs22\\cf1 Hyperlink;}{\\*\\ts4\\tsrowd\\fs22\\ql\\trautofit1\\tscellpaddfl3\\tscellpaddl108\\tscellpaddfr3\\tscellpaddr108\\tsvertalt\\cltxlrtb Normal Table;}{\\*\\ts5\\tsrowd\\sbasedon4\\fs22\\ql\\trbrdrt\\brdrs\\brdrw10\\trbrdrl\\brdrs\\brdrw10\\trbrdrb\\brdrs\\brdrw10\\trbrdrr\\brdrs\\brdrw10\\trbrdrh\\brdrs\\brdrw10\\trbrdrv\\brdrs\\brdrw10\\trautofit1\\tscellpaddfl3\\tscellpaddl108\\tscellpaddfr3\\tscellpaddr108\\tsvertalt\\cltxlrtb Table Simple 1;}}\\nouicompat\\splytwnine\\htmautsp\\sectd\\pard\\plain\\ql\\fs22\\par}',NULL,'2015-04-17 05:01:49','India Standard Time','6c469e6f-d39a-11e4-87a9-1c659df72b8d','2015-04-19 04:09:12','India Standard Time','204e7e4f-ddf1-11e4-8c23-1c659df72b8d',0,NULL,NULL,NULL,'India Standard Time'),('de67ff1e-2144-11e5-b8c6-005056c00008','439dd8e8-0f58-11e5-a531-000c29356af5',1,'Client PopUp',0,'{\\rtf1\\deff0{\\fonttbl{\\f0 Calibri;}}{\\colortbl ;\\red0\\green0\\blue255 ;}{\\*\\defchp \\fs22}{\\*\\listoverridetable}{\\stylesheet {\\ql\\fs22 Normal;}{\\*\\cs1\\fs22 Default Paragraph Font;}{\\*\\cs2\\sbasedon1\\fs22 Line Number;}{\\*\\cs3\\ul\\fs22\\cf1 Hyperlink;}{\\*\\ts4\\tsrowd\\fs22\\ql\\trautofit1\\tscellpaddfl3\\tscellpaddl108\\tscellpaddfr3\\tscellpaddr108\\tsvertalt\\cltxlrtb Normal Table;}{\\*\\ts5\\tsrowd\\sbasedon4\\fs22\\ql\\trbrdrt\\brdrs\\brdrw10\\trbrdrl\\brdrs\\brdrw10\\trbrdrb\\brdrs\\brdrw10\\trbrdrr\\brdrs\\brdrw10\\trbrdrh\\brdrs\\brdrw10\\trbrdrv\\brdrs\\brdrw10\\trautofit1\\tscellpaddfl3\\tscellpaddl108\\tscellpaddfr3\\tscellpaddr108\\tsvertalt\\cltxlrtb Table Simple 1;}}\\nouicompat\\splytwnine\\htmautsp\\sectd\\pard\\plain\\ql\\fs22\\par}',NULL,'2015-07-03 05:31:43','India Standard Time','eb30061d-df3d-11e4-98f6-1c659df72b8d','2015-07-03 05:33:15','India Standard Time','eb30061d-df3d-11e4-98f6-1c659df72b8d',0,NULL,NULL,NULL,'India Standard Time'),('f2196058-e4cc-11e4-9c8d-70f395293eeb','411aad8f-d39a-11e4-87a9-1c659df72b8d',1,'Handle Regulatory Compliance popup',0,'{\\rtf1\\deff0{\\fonttbl{\\f0 Calibri;}}{\\colortbl ;\\red0\\green0\\blue255 ;}{\\*\\defchp \\fs22}{\\*\\listoverridetable}{\\stylesheet {\\ql\\fs22 Normal;}{\\*\\cs1\\fs22 Default Paragraph Font;}{\\*\\cs2\\sbasedon1\\fs22 Line Number;}{\\*\\cs3\\ul\\fs22\\cf1 Hyperlink;}{\\*\\ts4\\tsrowd\\fs22\\ql\\trautofit1\\tscellpaddfl3\\tscellpaddl108\\tscellpaddfr3\\tscellpaddr108\\tsvertalt\\cltxlrtb Normal Table;}{\\*\\ts5\\tsrowd\\sbasedon4\\fs22\\ql\\trbrdrt\\brdrs\\brdrw10\\trbrdrl\\brdrs\\brdrw10\\trbrdrb\\brdrs\\brdrw10\\trbrdrr\\brdrs\\brdrw10\\trbrdrh\\brdrs\\brdrw10\\trbrdrv\\brdrs\\brdrw10\\trautofit1\\tscellpaddfl3\\tscellpaddl108\\tscellpaddfr3\\tscellpaddr108\\tsvertalt\\cltxlrtb Table Simple 1;}}\\nouicompat\\splytwnine\\htmautsp\\sectd\\pard\\plain\\ql\\fs22\\par}',NULL,'2015-04-17 06:40:37','India Standard Time','95a7c238-d6ad-11e4-98c1-1c659df72b8d','2015-04-17 06:48:59','India Standard Time','95a7c238-d6ad-11e4-98c1-1c659df72b8d',1,NULL,NULL,NULL,'India Standard Time');
/*!40000 ALTER TABLE `meta_eventhandler` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:39
