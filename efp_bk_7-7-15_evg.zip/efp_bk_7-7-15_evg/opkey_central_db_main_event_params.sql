CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_event_params`
--

DROP TABLE IF EXISTS `main_event_params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_event_params` (
  `eparam_id` varchar(64) NOT NULL,
  `event_id` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `datatype` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `position` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eparam_id`),
  KEY `FK_main_event_params__main_events` (`event_id`),
  CONSTRAINT `FK_main_event_params__main_events` FOREIGN KEY (`event_id`) REFERENCES `main_events` (`event_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_event_params`
--

LOCK TABLES `main_event_params` WRITE;
/*!40000 ALTER TABLE `main_event_params` DISABLE KEYS */;
INSERT INTO `main_event_params` VALUES ('0674889e-7ce7-4f31-abec-78ce61e4ff24','dbbe18c6-57e6-407f-9851-cb83ef6dad8e','Window Title','String','Specify the title of Pop-up/Window which is to be handled.',0),('64d5bc3f-56a9-4bab-853f-11f7669f6d09','57027f61-93a6-4860-a672-e984d85c14a0','Error','String','Specify the plugin specific error which will occur during execution',0),('7eed8b87-b1e1-4e28-8558-1d91bceddb39','dbbe18c6-57e6-407f-9851-cb83ef6dad8e','Reg-ex','Boolean','Specify whether the provided window title is Regular Expression or not.',1);
/*!40000 ALTER TABLE `main_event_params` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:32
