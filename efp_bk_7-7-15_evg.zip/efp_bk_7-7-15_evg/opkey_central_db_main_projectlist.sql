CREATE DATABASE  IF NOT EXISTS `opkey_central_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `opkey_central_db`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: opkey_central_db
-- ------------------------------------------------------
-- Server version	5.6.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `main_projectlist`
--

DROP TABLE IF EXISTS `main_projectlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `main_projectlist` (
  `P_ID` varchar(63) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `AuditTrailLevel` varchar(45) NOT NULL,
  `CreatedOn` datetime NOT NULL,
  `CreatedOn_tz` varchar(255) NOT NULL,
  `CreatedBy` varchar(63) NOT NULL,
  `Mode` varchar(45) NOT NULL DEFAULT 'Default',
  PRIMARY KEY (`P_ID`),
  UNIQUE KEY `Unique_ProjectName` (`Name`),
  KEY `FK_main_projectlist_users` (`CreatedBy`),
  CONSTRAINT `FK_main_projectlist_users` FOREIGN KEY (`CreatedBy`) REFERENCES `main_users` (`U_ID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_projectlist`
--

LOCK TABLES `main_projectlist` WRITE;
/*!40000 ALTER TABLE `main_projectlist` DISABLE KEYS */;
INSERT INTO `main_projectlist` VALUES ('1c046676-0f5d-11e5-a533-000c29e97660','Systech_eFingurePrint','LowLevel','2015-06-10 10:40:25','Eastern Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','Team'),('411aad8f-d39a-11e4-87a9-1c659df72b8d','Systech_Citadel','HighLevel','2015-03-26 09:27:00','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','Team'),('439dd8e8-0f58-11e5-a531-000c29356af5','Systech_eFingerPrint','LowLevel','2015-06-10 10:05:46','Eastern Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','Team'),('f45ec806-13f5-11e5-bc30-005056c00008','test','HighLevel','2015-06-16 07:04:31','India Standard Time','e23faacf-f26f-480c-bbdc-f504276743a8','Team');
/*!40000 ALTER TABLE `main_projectlist` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-07 18:14:38
